package org.expodev.testkotlinapp

//import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import org.expodev.testkotlinapp.data.SearchRepository
import org.expodev.testkotlinapp.data.SearchRepositoryProvider
import org.expodev.testkotlinapp.data.SourceOfQuotes

const val TAG: String = "MainActivity"

class MainActivity : AppCompatActivity() {

    val compositeDisposable: CompositeDisposable = CompositeDisposable()
    val repository: SearchRepository = SearchRepositoryProvider.provideSearchRepository()
    private val list: MutableList<SourceOfQuotes> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        compositeDisposable.add(
            repository.searchSourcesOfQuotes()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe({result ->
                    result.forEach {
                        list.addAll(it)
                    }
                    Log.d(TAG, list.toString())
                })
        )


        //sr.searchQuotes()
    }
}
